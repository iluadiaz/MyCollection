﻿using System;
using Pokemon.Info;
using System.Collections.Generic;
using System.Linq;
using Users.Info;


namespace _367Project
{
    class Program
    {
        static void Main(string[] args)
        {
           Console.WriteLine("oops");
        }
    }
}
